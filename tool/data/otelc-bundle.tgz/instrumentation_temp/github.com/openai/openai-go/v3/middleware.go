// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package v3

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"os"
	"slices"
	"strconv"
	"strings"
	"sync"
	"time"

	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/codes"
	"go.opentelemetry.io/otel/metric"
	otelsemconv "go.opentelemetry.io/otel/semconv/v1.37.0"
	"go.opentelemetry.io/otel/trace"

	"go.opentelemetry.io/otelc/instrumentation/github.com/openai/openai-go/internal/streaming"
	"go.opentelemetry.io/otelc/instrumentation/github.com/openai/openai-go/v3/semconv"
	"go.opentelemetry.io/otelc/pkg/netutil"
	"go.opentelemetry.io/otelc/pkg/otelcconv"
	"go.opentelemetry.io/otelc/pkg/runtime"
)

// contentCaptureFromEnv reports whether the given environment-variable value
// enables content capture. It is a standalone function so that the comparison
// can be tested without touching the process-wide sync.OnceValue cache.
func contentCaptureFromEnv(value string) bool {
	return value == "true"
}

var captureContentEnabled = sync.OnceValue(func() bool {
	return contentCaptureFromEnv(os.Getenv("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT"))
})

const (
	maxRequestBodySize  = 1 << 20 // 1 MB
	maxResponseBodySize = 4 << 20 // 4 MB
)

// providerMapping is checked in order: the first entry whose keyword is a
// substring of the request host wins. It is a slice, not a map, because Go
// map iteration order is randomized on every range - a map here would make
// getProviderName non-deterministic whenever a host matched more than one
// keyword (see Issue #824).
var providerMapping = []struct { //nolint:gochecknoglobals // private lookup table
	keyword  string
	provider string
}{
	{"openai.com", "openai"},
	{"azure.com", "azure"},
	{"anthropic.com", "anthropic"},
	{"dashscope.aliyuncs", "qwen"},
	{"volces.com", "ark"},
	{"ark.cn", "ark"},
	{"hunyuan", "tencent"},
	{"tencentcloudapi", "tencent"},
	{"googleapis.com", "google"},
	{"generativelanguage", "google"},
	{"deepseek.com", "deepseek"},
	{"moonshot", "moonshot"},
	{"zhipuai.cn", "zhipu"},
	{"bigmodel.cn", "zhipu"},
	{"baidu.com", "baidu"},
	{"minimax", "minimax"},
	{"siliconflow", "siliconflow"},
	{"together", "together"},
	{"mistral", "mistral"},
	{"groq.com", "groq"},
	{"ollama", "ollama"},
	{"localhost", "local"},
	{"127.0.0.1", "local"},
}

func getProviderName(host string) string {
	for _, entry := range providerMapping {
		if strings.Contains(host, entry.keyword) {
			return entry.provider
		}
	}
	return "openai"
}

type operationType int

const (
	opChat operationType = iota
	opCompletion
	opEmbedding
	opUnknown
)

func classifyOperation(path string) operationType {
	if strings.HasSuffix(path, "chat/completions") {
		return opChat
	}
	if strings.HasSuffix(path, "completions") {
		return opCompletion
	}
	if strings.HasSuffix(path, "embeddings") {
		return opEmbedding
	}
	return opUnknown
}

// requestTruncatedWarnOnce and responseTruncatedWarnOnce log the
// size-cap-exceeded warning once per operationType rather than once per
// request. The message only ever varies by operation name and a constant
// cap, so there are a handful of distinct messages total; a workload that
// regularly exceeds the cap would otherwise log on every single request.
var (
	requestTruncatedWarnOnce  [opUnknown + 1]sync.Once
	responseTruncatedWarnOnce [opUnknown + 1]sync.Once
)

func operationName(op operationType) string {
	switch op {
	case opChat:
		return "chat"
	case opCompletion:
		return "text_completion"
	case opEmbedding:
		return "embeddings"
	default:
		return ""
	}
}

// readBounded reads up to limit bytes from body for attribute parsing while
// preserving the full stream for downstream consumers (the SDK or the HTTP
// caller). truncated reports whether body held more than limit bytes; in that
// case bodyBytes is nil so no caller can parse a cut-off prefix as JSON.
func readBounded(
	body io.ReadCloser,
	limit int64,
) ([]byte, bool, io.ReadCloser, error) {
	var buf bytes.Buffer
	tee := io.TeeReader(body, &buf)
	// Read one byte past the limit so a full body can be told apart from one
	// that was cut short. That extra byte is still captured by the tee, so
	// reassembled below reproduces the stream in full either way.
	read, err := io.ReadAll(io.LimitReader(tee, limit+1))
	reassembled := struct {
		io.Reader
		io.Closer
	}{io.MultiReader(&buf, body), body}
	if int64(len(read)) > limit {
		return nil, true, reassembled, err
	}
	return read, false, reassembled, err
}

// OtelMiddleware returns an HTTP middleware that creates spans for OpenAI API
// calls following GenAI semantic conventions.
func OtelMiddleware() func(*http.Request, func(*http.Request) (*http.Response, error)) (*http.Response, error) {
	return otelMiddleware(captureContentEnabled)
}

func otelMiddleware(
	isContentCaptureEnabled func() bool,
) func(*http.Request, func(*http.Request) (*http.Response, error)) (*http.Response, error) {
	return func(req *http.Request, next func(*http.Request) (*http.Response, error)) (*http.Response, error) {
		if req.Body == nil {
			return next(req)
		}

		op := classifyOperation(req.URL.Path)
		if op == opUnknown {
			return next(req)
		}

		start := time.Now()
		provider := getProviderName(req.URL.Host)
		opName := operationName(op)

		// Read a bounded copy for attribute parsing, but preserve the full body for the SDK.
		bodyBytes, truncated, reassembledBody, err := readBounded(req.Body, maxRequestBodySize)
		req.Body = reassembledBody
		if err != nil {
			return next(req)
		}

		var model string
		var spanAttrs []attribute.KeyValue
		captureContent := isContentCaptureEnabled()
		var prompts []string

		if truncated {
			requestTruncatedWarnOnce[op].Do(func() {
				logger.Warn("openai request body exceeded size cap, skipping request attributes",
					"operation", opName, "cap_bytes", maxRequestBodySize)
			})
		} else {
			switch op {
			case opChat:
				model, spanAttrs, prompts = parseChatRequest(bodyBytes, captureContent)
			case opCompletion:
				model, spanAttrs, prompts = parseCompletionRequest(bodyBytes, captureContent)
			case opEmbedding:
				model, spanAttrs = parseEmbeddingRequest(bodyBytes)
			}

			if model == "" {
				return next(req)
			}
		}

		spanName := opName
		baseAttrs := []attribute.KeyValue{
			semconv.GenAISystem("openai"),
			otelsemconv.GenAIOperationNameKey.String(opName),
			otelsemconv.GenAIProviderNameKey.String(provider),
		}
		if model != "" {
			spanName = opName + " " + model
			baseAttrs = append(baseAttrs, otelsemconv.GenAIRequestModel(model))
		}
		serverAddress, serverPort := netutil.HTTPServerEndpoint(req.URL)
		if serverAddress != "" && serverPort > 0 {
			baseAttrs = append(baseAttrs,
				otelsemconv.ServerAddress(serverAddress),
				otelsemconv.ServerPort(serverPort),
			)
		}
		spanAttrs = append(baseAttrs, spanAttrs...)

		ctx := req.Context()
		ctx, span := tracer.Start(ctx, spanName,
			trace.WithSpanKind(trace.SpanKindClient),
			trace.WithAttributes(spanAttrs...),
		)

		if captureContent {
			recordContentEvents(span, "gen_ai.content.prompt", "gen_ai.prompt", prompts)
		}
		ctx = runtime.SuppressHTTPClientInstrumentation(ctx)
		req = req.WithContext(ctx)

		// Record the operation duration on every exit path below.
		// For streaming responses, the duration metric is recorded when the stream
		// finishes (mirroring the span lifetime) via newStreamingReader.
		// errorAttrs carries error.type on error paths and is empty on success.
		var errorAttrs []attribute.KeyValue
		isStreaming := false
		defer func() {
			if isStreaming {
				return
			}
			if operationDuration != nil {
				attrs := slices.Concat(baseAttrs, errorAttrs)
				operationDuration.Record(ctx, time.Since(start).Seconds(),
					metric.WithAttributes(attrs...))
			}
		}()

		resp, err := next(req)
		if err != nil {
			errorTypeAttr := otelsemconv.ErrorType(err)
			span.SetStatus(codes.Error, err.Error())
			span.RecordError(err)
			span.SetAttributes(errorTypeAttr)
			span.End()
			errorAttrs = []attribute.KeyValue{errorTypeAttr}
			return resp, err
		}

		if resp.StatusCode >= 400 {
			span.RecordError(errors.New(resp.Status))
			span.SetStatus(codes.Error, resp.Status)
			span.SetAttributes(otelsemconv.ErrorTypeKey.String(strconv.Itoa(resp.StatusCode)))
			span.End()
			errorAttrs = []attribute.KeyValue{otelsemconv.ErrorTypeKey.String(strconv.Itoa(resp.StatusCode))}
			return resp, nil
		}

		contentType := strings.TrimSpace(strings.SplitN(resp.Header.Get("Content-Type"), ";", 2)[0])
		isStreaming = strings.EqualFold(contentType, "text/event-stream")

		if isStreaming {
			span.SetAttributes(otelcconv.GenAIRequestIsStream(true))
			resp.Body = newStreamingReader(resp.Body, span, start, op, captureContent, func() {
				if operationDuration != nil {
					attrs := slices.Concat(baseAttrs, errorAttrs)
					operationDuration.Record(ctx, time.Since(start).Seconds(),
						metric.WithAttributes(attrs...))
				}
			})
		} else {
			handleNonStreamingResponse(ctx, resp, span, start, op, captureContent)
		}

		return resp, nil
	}
}

func handleNonStreamingResponse(
	_ context.Context,
	resp *http.Response,
	span trace.Span,
	_ time.Time,
	op operationType,
	captureContent bool,
) {
	defer span.End()

	// Read a bounded preview for parsing, but reassemble the full body for callers.
	bodyBytes, truncated, reassembledBody, err := readBounded(resp.Body, maxResponseBodySize)
	resp.Body = reassembledBody
	if err != nil {
		return
	}
	if truncated {
		responseTruncatedWarnOnce[op].Do(func() {
			logger.Warn("openai response body exceeded size cap, skipping response attributes",
				"operation", operationName(op), "cap_bytes", maxResponseBodySize)
		})
		return
	}

	switch op {
	case opChat:
		parseChatResponse(bodyBytes, span, captureContent)
	case opCompletion:
		parseCompletionResponse(bodyBytes, span, captureContent)
	case opEmbedding:
		parseEmbeddingResponse(bodyBytes, span)
	}
}

func parseChatRequest(body []byte, captureContent bool) (string, []attribute.KeyValue, []string) {
	var req struct {
		Model               string   `json:"model"`
		MaxTokens           *int64   `json:"max_tokens,omitempty"`
		MaxCompletionTokens *int64   `json:"max_completion_tokens,omitempty"`
		Temperature         *float64 `json:"temperature,omitempty"`
		TopP                *float64 `json:"top_p,omitempty"`
		FrequencyPenalty    *float64 `json:"frequency_penalty,omitempty"`
		PresencePenalty     *float64 `json:"presence_penalty,omitempty"`
	}
	if err := json.Unmarshal(body, &req); err != nil {
		return "", nil, nil
	}

	var attrs []attribute.KeyValue
	if req.MaxCompletionTokens != nil {
		attrs = append(attrs, otelsemconv.GenAIRequestMaxTokensKey.Int64(*req.MaxCompletionTokens))
	} else if req.MaxTokens != nil {
		attrs = append(attrs, otelsemconv.GenAIRequestMaxTokensKey.Int64(*req.MaxTokens))
	}
	if req.Temperature != nil {
		attrs = append(attrs, otelsemconv.GenAIRequestTemperature(*req.Temperature))
	}
	if req.TopP != nil {
		attrs = append(attrs, otelsemconv.GenAIRequestTopP(*req.TopP))
	}
	if req.FrequencyPenalty != nil {
		attrs = append(attrs, otelsemconv.GenAIRequestFrequencyPenalty(*req.FrequencyPenalty))
	}
	if req.PresencePenalty != nil {
		attrs = append(attrs, otelsemconv.GenAIRequestPresencePenalty(*req.PresencePenalty))
	}
	if !captureContent {
		return req.Model, attrs, nil
	}
	return req.Model, attrs, parseChatPrompts(body)
}

func parseCompletionRequest(body []byte, captureContent bool) (string, []attribute.KeyValue, []string) {
	var req struct {
		Model            string   `json:"model"`
		MaxTokens        *int64   `json:"max_tokens,omitempty"`
		Temperature      *float64 `json:"temperature,omitempty"`
		TopP             *float64 `json:"top_p,omitempty"`
		FrequencyPenalty *float64 `json:"frequency_penalty,omitempty"`
		PresencePenalty  *float64 `json:"presence_penalty,omitempty"`
	}
	if err := json.Unmarshal(body, &req); err != nil {
		return "", nil, nil
	}

	var attrs []attribute.KeyValue
	if req.MaxTokens != nil {
		attrs = append(attrs, otelsemconv.GenAIRequestMaxTokensKey.Int64(*req.MaxTokens))
	}
	if req.Temperature != nil {
		attrs = append(attrs, otelsemconv.GenAIRequestTemperature(*req.Temperature))
	}
	if req.TopP != nil {
		attrs = append(attrs, otelsemconv.GenAIRequestTopP(*req.TopP))
	}
	if req.FrequencyPenalty != nil {
		attrs = append(attrs, otelsemconv.GenAIRequestFrequencyPenalty(*req.FrequencyPenalty))
	}
	if req.PresencePenalty != nil {
		attrs = append(attrs, otelsemconv.GenAIRequestPresencePenalty(*req.PresencePenalty))
	}
	if !captureContent {
		return req.Model, attrs, nil
	}
	return req.Model, attrs, parseCompletionPrompts(body)
}

func parseChatPrompts(body []byte) []string {
	var req struct {
		Messages []map[string]json.RawMessage `json:"messages"`
	}
	if err := json.Unmarshal(body, &req); err != nil {
		return nil
	}

	prompts := make([]string, 0, len(req.Messages))
	for _, message := range req.Messages {
		if content := contentFromJSON(message["content"]); content != "" {
			prompts = append(prompts, content)
		}
	}
	return prompts
}

func parseCompletionPrompts(body []byte) []string {
	var req struct {
		Prompt json.RawMessage `json:"prompt"`
	}
	if err := json.Unmarshal(body, &req); err != nil || len(req.Prompt) == 0 {
		return nil
	}

	var prompt string
	if err := json.Unmarshal(req.Prompt, &prompt); err == nil {
		return []string{prompt}
	}

	var prompts []string
	if err := json.Unmarshal(req.Prompt, &prompts); err != nil {
		return nil
	}
	return prompts
}

func contentFromJSON(content json.RawMessage) string {
	content = bytes.TrimSpace(content)
	if len(content) == 0 || bytes.Equal(content, []byte("null")) {
		return ""
	}

	var text string
	if err := json.Unmarshal(content, &text); err == nil {
		return text
	}

	// Array content (e.g. multimodal parts): join the text parts so the event
	// stays readable instead of embedding base64 payloads in raw JSON.
	var parts []struct {
		Text string `json:"text"`
	}
	if err := json.Unmarshal(content, &parts); err == nil {
		texts := make([]string, 0, len(parts))
		for _, part := range parts {
			if part.Text != "" {
				texts = append(texts, part.Text)
			}
		}
		return strings.Join(texts, "\n")
	}

	// Last resort for other non-string content: compacted raw JSON.
	marshaled, err := json.Marshal(content)
	if err != nil {
		return ""
	}
	return string(marshaled)
}

func recordContentEvents(span trace.Span, name, key string, contents []string) {
	for _, content := range contents {
		if content == "" {
			continue
		}
		span.AddEvent(name, trace.WithAttributes(
			attribute.String(key, streaming.TruncateContent(content)),
		))
	}
}

func parseEmbeddingRequest(body []byte) (string, []attribute.KeyValue) {
	var req struct {
		Model string `json:"model"`
	}
	if err := json.Unmarshal(body, &req); err != nil {
		return "", nil
	}
	return req.Model, nil
}

func parseChatResponse(body []byte, span trace.Span, captureContent bool) {
	var resp struct {
		ID      string `json:"id"`
		Model   string `json:"model"`
		Choices []struct {
			FinishReason string `json:"finish_reason"`
		} `json:"choices"`
		Usage struct {
			PromptTokens        int64           `json:"prompt_tokens"`
			CompletionTokens    int64           `json:"completion_tokens"`
			TotalTokens         int64           `json:"total_tokens"`
			PromptTokensDetails json.RawMessage `json:"prompt_tokens_details"`
		} `json:"usage"`
	}
	if err := json.Unmarshal(body, &resp); err != nil {
		return
	}

	var reasons []string
	for _, c := range resp.Choices {
		if c.FinishReason != "" {
			reasons = append(reasons, c.FinishReason)
		}
	}
	if captureContent {
		recordContentEvents(span, "gen_ai.content.completion", "gen_ai.completion", parseChatCompletions(body))
	}

	span.SetAttributes(
		otelsemconv.GenAIResponseID(resp.ID),
		otelsemconv.GenAIResponseModel(resp.Model),
		otelsemconv.GenAIResponseFinishReasonsKey.StringSlice(reasons),
		otelsemconv.GenAIUsageInputTokensKey.Int64(resp.Usage.PromptTokens),
		otelsemconv.GenAIUsageOutputTokensKey.Int64(resp.Usage.CompletionTokens),
		otelcconv.GenAIUsageTotalTokensKey.Int64(resp.Usage.TotalTokens),
	)

	// OpenAI serves part of the prompt from an automatic cache and reports the
	// count under prompt_tokens_details. It is already included in
	// prompt_tokens, so this is a breakdown of the input count and is never
	// added to gen_ai.usage.input_tokens - unlike Anthropic, whose input_tokens
	// excludes cache reads and therefore has to fold them back in. Recorded only
	// when the request actually hit the cache, matching the Anthropic
	// instrumentation.
	if cached := cachedPromptTokens(resp.Usage.PromptTokensDetails); cached > 0 {
		span.SetAttributes(otelcconv.GenAIUsageCacheReadInputTokensKey.Int64(cached))
	}
}

func parseCompletionResponse(body []byte, span trace.Span, captureContent bool) {
	var resp struct {
		ID      string `json:"id"`
		Model   string `json:"model"`
		Choices []struct {
			FinishReason string `json:"finish_reason"`
		} `json:"choices"`
		Usage struct {
			PromptTokens        int64           `json:"prompt_tokens"`
			CompletionTokens    int64           `json:"completion_tokens"`
			TotalTokens         int64           `json:"total_tokens"`
			PromptTokensDetails json.RawMessage `json:"prompt_tokens_details"`
		} `json:"usage"`
	}
	if err := json.Unmarshal(body, &resp); err != nil {
		return
	}

	var reasons []string
	for _, c := range resp.Choices {
		if c.FinishReason != "" {
			reasons = append(reasons, c.FinishReason)
		}
	}
	if captureContent {
		recordContentEvents(span, "gen_ai.content.completion", "gen_ai.completion", parseCompletionContents(body))
	}

	span.SetAttributes(
		otelsemconv.GenAIResponseID(resp.ID),
		otelsemconv.GenAIResponseModel(resp.Model),
		otelsemconv.GenAIResponseFinishReasonsKey.StringSlice(reasons),
		otelsemconv.GenAIUsageInputTokensKey.Int64(resp.Usage.PromptTokens),
		otelsemconv.GenAIUsageOutputTokensKey.Int64(resp.Usage.CompletionTokens),
		otelcconv.GenAIUsageTotalTokensKey.Int64(resp.Usage.TotalTokens),
	)

	// OpenAI serves part of the prompt from an automatic cache and reports the
	// count under prompt_tokens_details. It is already included in
	// prompt_tokens, so this is a breakdown of the input count and is never
	// added to gen_ai.usage.input_tokens - unlike Anthropic, whose input_tokens
	// excludes cache reads and therefore has to fold them back in. Recorded only
	// when the request actually hit the cache, matching the Anthropic
	// instrumentation.
	if cached := cachedPromptTokens(resp.Usage.PromptTokensDetails); cached > 0 {
		span.SetAttributes(otelcconv.GenAIUsageCacheReadInputTokensKey.Int64(cached))
	}
}

// cachedPromptTokens returns usage.prompt_tokens_details.cached_tokens, or 0
// when the field is absent or malformed. It is decoded separately from the
// rest of the response so that a malformed details object cannot drop the
// other usage attributes along with it.
func cachedPromptTokens(details json.RawMessage) int64 {
	var d struct {
		CachedTokens int64 `json:"cached_tokens"`
	}
	if len(details) == 0 || json.Unmarshal(details, &d) != nil {
		return 0
	}
	return d.CachedTokens
}

func parseChatCompletions(body []byte) []string {
	var resp struct {
		Choices []struct {
			Message map[string]json.RawMessage `json:"message"`
		} `json:"choices"`
	}
	if err := json.Unmarshal(body, &resp); err != nil {
		return nil
	}

	completions := make([]string, 0, len(resp.Choices))
	for _, choice := range resp.Choices {
		if content := contentFromJSON(choice.Message["content"]); content != "" {
			completions = append(completions, content)
		}
	}
	return completions
}

func parseCompletionContents(body []byte) []string {
	var resp struct {
		Choices []struct {
			Text string `json:"text"`
		} `json:"choices"`
	}
	if err := json.Unmarshal(body, &resp); err != nil {
		return nil
	}

	completions := make([]string, 0, len(resp.Choices))
	for _, choice := range resp.Choices {
		if choice.Text != "" {
			completions = append(completions, choice.Text)
		}
	}
	return completions
}

func parseEmbeddingResponse(body []byte, span trace.Span) {
	var resp struct {
		Model string `json:"model"`
		Usage struct {
			PromptTokens int64 `json:"prompt_tokens"`
			TotalTokens  int64 `json:"total_tokens"`
		} `json:"usage"`
	}
	if err := json.Unmarshal(body, &resp); err != nil {
		return
	}

	span.SetAttributes(
		otelsemconv.GenAIResponseModel(resp.Model),
		otelsemconv.GenAIUsageInputTokensKey.Int64(resp.Usage.PromptTokens),
		otelcconv.GenAIUsageTotalTokensKey.Int64(resp.Usage.TotalTokens),
	)
}
